

<?php $__env->startSection('title', 'Chat'); ?>
<?php $__env->startSection('body'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <!-- END: Header-->

        <div class="content-area-wrapper">
            <div class="sidebar-left">
                <div class="sidebar">
                    <!-- User Chat profile area -->
                    <div class="chat-profile-sidebar">
                        <header class="chat-profile-header">
                            <span class="close-icon">
                                <i class="feather icon-x"></i>
                            </span>
                            <div class="header-profile-sidebar">
                                <div class="avatar">
                                    <img src="../app-assets/images/portrait/small/avatar-s-11.png" alt="user_avatar" height="70" width="70">
                                    <span class="avatar-status-online avatar-status-lg"></span>
                                </div>
                                <h4 class="chat-user-name">John Doe</h4>
                            </div>
                        </header>
                        <div class="profile-sidebar-area">
                            <div class="scroll-area">
                                <h6>About</h6>
                                <div class="about-user">
                                    <fieldset class="mb-0">
                                        <textarea data-length="120" class="form-control char-textarea" id="textarea-counter" rows="5" placeholder="About User">Dessert chocolate cake lemon drops jujubes. Biscuit cupcake ice cream bear claw brownie brownie marshmallow.</textarea>
                                    </fieldset>
                                    <small class="counter-value float-right"><span class="char-count">108</span> / 120 </small>
                                </div>
                                <h6 class="mt-3">Status</h6>
                                <ul class="list-unstyled user-status mb-0">
                                    <li class="pb-50">
                                        <fieldset>
                                            <div class="vs-radio-con vs-radio-success">
                                                <input type="radio" name="userStatus" value="online" checked="checked">
                                                <span class="vs-radio">
                                                    <span class="vs-radio--border"></span>
                                                    <span class="vs-radio--circle"></span>
                                                </span>
                                                <span class="">Active</span>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="pb-50">
                                        <fieldset>
                                            <div class="vs-radio-con vs-radio-danger">
                                                <input type="radio" name="userStatus" value="busy">
                                                <span class="vs-radio">
                                                    <span class="vs-radio--border"></span>
                                                    <span class="vs-radio--circle"></span>
                                                </span>
                                                <span class="">Do Not Disturb</span>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="pb-50">
                                        <fieldset>
                                            <div class="vs-radio-con vs-radio-warning">
                                                <input type="radio" name="userStatus" value="away">
                                                <span class="vs-radio">
                                                    <span class="vs-radio--border"></span>
                                                    <span class="vs-radio--circle"></span>
                                                </span>
                                                <span class="">Away</span>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="pb-50">
                                        <fieldset>
                                            <div class="vs-radio-con vs-radio-secondary">
                                                <input type="radio" name="userStatus" value="offline">
                                                <span class="vs-radio">
                                                    <span class="vs-radio--border"></span>
                                                    <span class="vs-radio--circle"></span>
                                                </span>
                                                <span class="">Offline</span>
                                            </div>
                                        </fieldset>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!--/ User Chat profile area -->
                    <!-- Chat Sidebar area -->
                    <div class="sidebar-content card">
                        <span class="sidebar-close-icon">
                            <i class="feather icon-x"></i>
                        </span>
                        <div class="chat-fixed-search">
                            <div class="d-flex align-items-center">
                                <div class="sidebar-profile-toggle position-relative d-inline-flex">
                                    <div class="avatar">
                                        <img src="<?php echo e(url('/app-assets/images/portrait/small/profile.png')); ?>" alt="user_avatar" height="40" width="40">
                                        <span class="avatar-status-online"></span>
                                    </div>
                                    <div class="bullet-success bullet-sm position-absolute"></div>
                                </div>
                                <fieldset class="form-group position-relative has-icon-left mx-1 my-0 w-100">
                                    <input type="text" class="form-control round" id="chat-search" placeholder="Search or start a new chat">
                                    <div class="form-control-position">
                                        <i class="feather icon-search"></i>
                                    </div>
                                </fieldset>
                            </div>
                        </div>
                        <div id="users-list"  class="chat-user-list list-group position-relative">
                            <h3 class="primary p-1 mb-0">Chats</h3>
                            <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="chat-users-list-wrapper media-list" >
                                <?php 
                            $email=$person->person_email;
                                ?>
                     
                             <li  onclick="getPaging(this.id)"  id="<?php echo e($person->person_email); ?>"> 
                                  
                            <div class="pr-1">
                                        <span class="avatar m-0 avatar-md"><img class="media-object rounded-circle" src="<?php echo e(url('/app-assets/images/portrait/small/profile.png')); ?>" height="42" width="42" alt="Generic placeholder image">
                                            <i></i>
                                        </span>
                                    </div>
                           
                                    <div class="user-chat-info">
                                        <div class="contact-info">
                                            <h5 class="font-weight-bold mb-0"><?php echo e($person->person_name); ?></h5>
                                            <p class="truncate"><?php echo e($person->person_type); ?></p>

                                        </div>
                                        <div class="contact-meta">
                                            <span class="float-right mb-25"><?php echo e($person->person_time); ?></span>
                                          
                                        </div>
                                    </div>
                                 
                                </li>
                            
                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <!--/ Chat Sidebar area -->

                </div>
            </div>
            <div class="content-right">
                <div class="content-wrapper">
                    <div class="content-header row">
                    </div>
                    <div class="content-body">
                        <div class="chat-overlay"></div>
                        <section class="chat-app-window">
                            <div class="start-chat-area">
                                <span class="mb-1 start-chat-icon feather icon-message-square"></span>
                                <h4 class="py-50 px-1 sidebar-toggle start-chat-text">Start Conversation</h4>
                            </div>
                            <div class="active-chat d-none">
                                <div class="chat_navbar">
                                    <header class="chat_header d-flex justify-content-between align-items-center p-1">
                                        <div class="vs-con-items d-flex align-items-center">
                                            <div class=" d-block d-lg-none mr-1"><i class="feather icon-menu font-large-1"></i></div>
                                            <div class="avatar  m-0 m-0 mr-1" >
                                                <img src="<?php echo e(url('/app-assets/images/portrait/small/profile.png')); ?>" alt="" height="40" width="40"  id="emailid" onclick="getprofile(this.value)" />
                                                <span class="avatar-status-busy"></span>
                                            </div>
                                            <h6 id="msg" class="mb-0"></h6>
                                        </div>
                                        <span class="favorite"><i class="feather icon-star font-medium-5"></i></span>
                                    </header>
                                </div>
                            
                                <div class="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                            
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                <h4 class="modal-title" id="myModalLabel2"></h4>
                                            </div>
                            
                                            <div class="modal-body">
                                                <div id="userprofile"></div>
                                            </div>
                            
                                        </div><!-- modal-content -->
                                    </div><!-- modal-dialog -->
                                </div><!-- modal -->
                                
                                
                            </div>
                                <div class="user-chats">
                                   <div id="model_mid"></div>
                                
                                      
                                 

                                
                                 
                                </div> 
                                <div class="chat-app-form">
                                    <form class="chat-app-input d-flex" onsubmit="enter_chat();" action="javascript:void(0);">
                                        <input type="text" class="form-control message mr-1 ml-50" id="iconLeft4-1" placeholder="Type your message">
                                        <button type="button" class="btn btn-primary send" onclick="enter_chat();"><i class="fa fa-paper-plane-o d-lg-none"></i> <span class="d-none d-lg-block">Send</span></button>
                                    </form>
                                </div>
                            </div>
                        </section>
                        <!-- User Chat profile right area -->
                        <div class="user-profile-sidebar">
                            <header class="user-profile-header">
                                <span class="close-icon">
                                    <i class="feather icon-x"></i>
                                </span>
                                <div class="header-profile-sidebar">
                                    <div class="avatar">
                                        <img src="<?php echo e(url('/app-assets/images/portrait/small/profile.png')); ?>" alt="user_avatar" height="70" width="70">
                                        <span class="avatar-status-busy avatar-status-lg"></span>
                                    </div>
                                   
                                </div>
                            </header>
                            <div class="user-profile-sidebar-area p-2">
                              
                               
                            </div>
                        </div>
                        <!--/ User Chat profile right area -->

                    </div>
                </div>
            </div>
        </div>
   
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script> 
  
      function getPaging(getvalue)
{
    
//alert(getvalue);
document.getElementById("msg").innerHTML = getvalue;
document.getElementById("emailid").value = getvalue;
//alert(getvalue);
            var email = getvalue;
     
           
                $.ajax({
                    url: "<?php echo e(url('/chatpost')); ?>",
                
                    type: "POST",
                    data: {
                    
                        email: email 
                    },
                    cache: false,
                    success: function(response) {
            // alert(response);
            var result=JSON.parse(response);
        
        
            var list = '';
        
            $.each(result, function (i, item) {
             list +='<div class="chats"><div class="chat"><div class="chat-avatar"><a class="avatar m-0" data-toggle="tooltip" href="#" data-placement="right" title="" data-original-title=""><img src="<?php echo e(url("/app-assets/images/portrait/small/profile.png")); ?>" alt="avatar" height="40" width="40" /></a></div><div class="chat-body"><div class="chat-content"><p >'+result[i].question+'</p></div></div></div><div class="chat chat-left" ><div class="chat-avatar"><a class="avatar m-0" data-toggle="tooltip" href="#" data-placement="left" title="" data-original-title=""><img src="<?php echo e(url("/app-assets/images/portrait/small/bot_avatar.png")); ?>" alt="avatar" height="40" width="40" /></a></div><div class="chat-body" ><div class="chat-content"><p>'+result[i].answers+'</p></div></div></div><div class="divider"><div class="divider-text">'+result[i].time+'</div></div></div>';
                                });//end each
            $('#model_mid').html(list); 

         },
         error: function(xhr, status, error) {
         console.error(xhr);
         }
     
       
                    
                });
         
           


}

    </script> 

   
    
    <script>
  
   
    function getprofile(getdata)
{



           var email = getdata;
    
          
               $.ajax({
                   url: "<?php echo e(url('/getprofile')); ?>",
                   type: "POST",
                   data: {
                       email: email   
                   },
                   cache: false,
                   success: function(data) {
           //alert(data);
           $('#myModal2').modal('show');
           var results=JSON.parse(data);
      
       
           var list = '';
           
           $.each(results, function (i, item) {

            list +='<p><b>Name :</b>'+results[i].person_name+'</p></br><p><b>email :</b>'+results[i].person_email+'</p></br><p><b>phone :</b>'+results[i].person_phone+'</p></br><p><b>type :</b>'+results[i].person_type+'</p></br><p><b>Last Online  :</b>'+results[i].created_at+'</p></br><p><b>Location :</b>'+results[i].City+','+results[i].State+ ',' +results[i].CountryName+ '</p>';
                               });//end each
           $('#userprofile').html(list); 
           
          
          
        },
        error: function(xhr, status, error) {
        console.error(xhr);
        }
    
      
                   
               });

}
</script>  
    <?php $__env->stopSection(); ?>


   
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AI-chatbot\resources\views/admin/chat.blade.php ENDPATH**/ ?>