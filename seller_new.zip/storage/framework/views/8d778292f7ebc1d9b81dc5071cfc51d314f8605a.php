<?php $__env->startSection('title', 'dashboard'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/app-assets/css/pages/data-list-view.css')); ?>">
<?php $__env->startSection('body'); ?>

<section id="data-list-view" class="data-list-view-header">
    <!-- DataTable starts -->
    <div class="table-responsive">
        <table class="table data-list-view">
            <thead>
                                    <tr>
                                        <th>id</th>
                                        <th>user_id</th>
                                        <th>product_id </th>
                                        <th>rating</th>
                                        <th>photos</th>
                                        <th>review</th>
                                        <th>created_at</th>
                                        <th>updated_at</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td><?php echo e($product->user_id); ?></td>
                                        <td><?php echo e($product->product_id); ?></td>
                                        <td><?php echo e($product->rating); ?></td>
                                        <td><?php echo e($product->photos); ?></td>
                                        <td><?php echo e($product->review); ?></td>
                                        <td>
                                        <div class="chip chip-warning">
                                        <div class="chip-body">
                                           <div class="chip-text"><?php echo e($product->created_at); ?></div>
                                          </div>
                                       </div>
                                         </td>
                                          <td>
                                         <div class="chip chip-warning">
                                           <div class="chip-body">
                                          <div class="chip-text"><?php echo e($product->updated_at); ?></div>
                                         </div>
                                          </div>
                                           </td>
                                        
                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                
                            </table>
        </table>
    </div>
    <!-- DataTable ends -->


    <!-- add new sidebar ends -->
</section>


<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('/app-assets/js/scripts/ui/data-list-view.js')); ?>"></script>
<!-- BEGIN: Page Vendor JS-->
<!-- END: Page Vendor JS-->
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seller_new\resources\views/product/productreview.blade.php ENDPATH**/ ?>