


    <div class="ps-my-account">
        <div class="container">
            <div class="ps-form--account ps-tab-root">
                <div class="card card-primary card-outline">
                    <div class="card-body" id="sign-in">
                        <div class="ps-form__content">
                            <div class="card-box-shared-body">
                            
                                    <div class="alert alert-success" role="alert">
                                    
                                    </div>
                            

                             
                                <form class="d-inline" method="POST" action="">
                                
                                    <input type="hidden" name="id" value="">

                                    <button type="submit" class="btn btn-link p-0 m-0 align-baseline">
                                    </button>

                                </form>
                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </div>


<?php /**PATH E:\XAMPP\htdocs\seller-panel\resources\views/auth/verify.blade.php ENDPATH**/ ?>