
<?php $__env->startSection('title', 'dashboard'); ?>
<?php $__env->startSection('body'); ?>


<section id="column-selectors">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All products</h4>
                  
                </div>
                <div class="card-content">
                    <div class="card-body card-dashboard">
                  
                        <div class="table-responsive">
                        <div class="col-lg-6 col-md-12">
                        <div class="form-group">
                            <a href='product_create'><button type="button" class="btn mb-1 btn-primary btn-lg btn-block waves-effect waves-light float-right">Add a product</button></a>
                        </div>
                    </div>
                            <table class="table table-striped dataex-html5-selectors">
                                <thead>
                                    <tr>
                                        <th>id</th>
                                        <th>user_id</th>
                                        <th>category_id</th>
                                        <th>sub_category_id</th>
                                        <th>name</th>
                                        <th>slug</th>
                                        <th>photo</th>
                                        <th>description</th>
                                        <th>price</th>
                                        <th>stock</th>
                                        <th>status</th>
                                        <th>created_at</th>
                                        <th>updated_at</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  
                                    <?php $__currentLoopData = $productArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td><?php echo e($product->user_id); ?></td>
                                        <td><?php echo e($product->category_id); ?></td>
                                        <td><?php echo e($product->sub_category_id); ?></td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->slug); ?></td>
                                        <td><?php echo e($product->photo); ?></td>
                                        <td><?php echo e($product->description); ?></td>
                                        <td><?php echo e($product->price); ?></td>
                                        <td><?php echo e($product->stock); ?></td>
                                        <td><?php echo e($product->status); ?></td>
                                        <td>
                                        <div class="chip chip-warning">
                                        <div class="chip-body">
                                           <div class="chip-text"><?php echo e($product->created_at); ?></div>
                                          </div>
                                       </div>
                                         </td>
                                          <td>
                                         <div class="chip chip-warning">
                                           <div class="chip-body">
                                          <div class="chip-text"><?php echo e($product->updated_at); ?></div>
                                         </div>
                                          </div>
                                           </td>
                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Column selectors with Export Options and print table -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\seller-panel\resources\views/product/products.blade.php ENDPATH**/ ?>