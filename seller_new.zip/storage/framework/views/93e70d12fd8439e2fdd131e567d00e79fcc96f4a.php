
<?php $__env->startSection('title', 'Live-view'); ?>
<?php $__env->startSection('body'); ?>

<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <h2 class="content-header-title float-left mb-0">Live View</h2>
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Home</a>
                            </li>
                            <li class="breadcrumb-item"><a href="#">Data List</a>
                            </li>
                            <li class="breadcrumb-item active">Live View
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
            <div class="form-group breadcrum-right">
                <div class="dropdown">
                    <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="feather icon-settings"></i></button>
                    <div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item" href="#">Chat</a><a class="dropdown-item" href="#">Email</a><a class="dropdown-item" href="#">Calendar</a></div>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <!-- Data list view starts -->
        <section id="basic-datatable">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                           
                        </div>
                        <div class="card-content">
                            <div class="card-body card-dashboard">
                                <p class="card-text"></p>
                                <div class="table-responsive">
                                    <table class="table zero-configuration">
                                        <thead>
                                            <tr>
                                              
                                                <th>S.NO</th>
                                                <th>Name</th>
                                                <th>Stage</th>
                                               
                                                <th>Device</th>
                                                <th>Location</th>
                                                <th>page</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(count($prospect)): ?>
                                            <?php $__currentLoopData = $prospect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                              <td><?php echo e($visitors->id); ?></td>
                                                <td><div class="avatar bg-primary mr-1">
                                                    <div class="avatar-content">
                                                       #V
                                                    </div>
                                                </div>  <?php echo e($visitors->name); ?></td>
                                                <td><div class="badge badge-info badge-md mr-1 mb-1"><?php echo e($visitors->stage); ?></div>
                                 </td>
                                                
                                               
                                             
                                                <td _ngcontent-c14="" class="parent_with_child_in_center">
                                                    <!----><div _ngcontent-c14="" class="fx11 rfx ng-star-inserted" style="width: 75px;">
                                                   
                                                       
                                                     <?php if($visitors->devices =='Desktop device'): ?>
                                                            <img _ngcontent-c14="" data-toggle="tooltip" placement="bottom" style="height: 15px;" data-original-title="<?php echo e($visitors->devices); ?>" src="https://cdn.intelliticks.com/prod/20201123/ua-images/device/pc.png">
                                                      <?php else: ?>
                                                        <img _ngcontent-c14="" data-toggle="tooltip" data-original-title="<?php echo e($visitors->devices); ?>" placement="bottom" style="height: 15px;" src="https://cdn.intelliticks.com/prod/20201228/ua-images/device/phone.png">
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td><?php echo e($visitors->City); ?>,<?php echo e($visitors->State); ?> <?php echo e($visitors->CountryName); ?></td>
                                                <td><?php echo e($visitors->website_page); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                   
                                          
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Name</th>
                                                <th>Stage</th>
                                                <th>page</th>
                                                <th>Device</th>
                                                <th>Location</th>
                                                <th>Last Online</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Data list view end -->

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AI-chatbot\resources\views/admin/live-view.blade.php ENDPATH**/ ?>