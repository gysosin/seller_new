<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('master.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="vertical-layout vertical-menu-modern semi-dark-layout 2-columns  navbar-floating footer-static   " data-open="click" data-menu="vertical-menu-modern" data-col="content-left-sidebar">
    <?php echo $__env->make('master.main_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="app-content content">

        <!-- BEGIN: Header-->
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <?php echo $__env->make('master.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Loading ends -->

 
    <?php echo $__env->yieldContent('body'); ?>
    <!-- *************
				************ Main container end *************
				************* -->


  </div>

  <!-- *************
				************ Required JavaScript Files *************
			************* -->
  <?php echo $__env->make('master.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH E:\XAMPP\htdocs\seller-panel\resources\views/layout/master.blade.php ENDPATH**/ ?>