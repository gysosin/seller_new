
<?php $__env->startSection('title', 'faq'); ?>
<?php $__env->startSection('body'); ?>


    <!-- BEGIN: Content-->
   

  
        <!-- END: Header-->

        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0">FAQ</h2>
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Home</a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="#">Pages</a>
                                    </li>
                                    <li class="breadcrumb-item active">FAQ
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
                    <div class="form-group breadcrum-right">
                        <div class="dropdown">
                            <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="feather icon-settings"></i></button>
                            <div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item" href="#">Chat</a><a class="dropdown-item" href="#">Email</a><a class="dropdown-item" href="#">Calendar</a></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <section id="faq-search">
                    <div class="row">
                        <div class="col-12">
                            <div class="card faq-bg white">
                                <div class="card-content">
                                    <div class="card-body p-sm-4 p-2">
                                        <h1 class="white">Have Any Questions?</h1>
                                        <p class="card-text mb-2">
                                            Bonbon sesame snaps lemon drops marshmallow ice cream carrot cake croissant wafer.
                                        </p>
                                        <form>
                                            <fieldset class="form-group position-relative has-icon-left mb-0">
                                                <input type="text" class="form-control form-control-lg" id="searchbar" placeholder="Search">
                                                <div class="form-control-position">
                                                    <i class="feather icon-search px-1"></i>
                                                </div>
                                            </fieldset>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="faq">
                    <div class="row">
                     
                     
                        <div class="col-xl-9 col-md-7 col-12">
                            <div class="card  border-0 shadow-none collapse-icon accordion-icon-rotate">
                                <div class="card-body p-0">
                                    <?php $__currentLoopData = $chatbot_hints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat_hints): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="accordion search-content-info" id="accordionExample">
                                        <div class="collapse-margin search-content mt-0">
                                            <div class="card-header" id="headingOne">
                                                <span class="lead collapse-title" role="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                 <b>Question: </b>    <?php echo e($chat_hints->question); ?>

                                                </span>
                                            </div>
                                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                <div class="card-body">
                                                    <b>Answers: </b>    <?php echo e($chat_hints->reply); ?>

                                                </div>
                                            </div>
                                        </div>
                                      

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                           <div class="col-xl-3 col-md-5 col-12">
                          
                               
                            <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#primary">
                             Add
                            </button>
                                 
                        </div> 
                    </div>
                </section>

            </div>
        </div>
        <div class="modal fade text-left" id="primary" tabindex="-1" role="dialog" aria-labelledby="myModalLabel160" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
                <div class="modal-content">
                    <div class="modal-header bg-primary white">
                        <h5 class="modal-title" id="myModalLabel160">Add</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <label>Question</label>
                    <input type="text" class="form-control">
                    <label>Answers</label>
                    <input type="text" class="form-control">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    <!-- END: Content-->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AI-chatbot\resources\views/admin/faq.blade.php ENDPATH**/ ?>