<script src="<?php echo e(url('/app-assets/vendors/js/vendors.min.js')); ?>"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<!-- END: Page Vendor JS-->
<script src="<?php echo e(url('/app-assets/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js')); ?>"></script>
<!-- BEGIN: Theme JS-->
<script src="<?php echo e(url('/app-assets/js/core/app-menu.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/js/core/app.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/js/scripts/components.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\seller_new\resources\views/master/script.blade.php ENDPATH**/ ?>