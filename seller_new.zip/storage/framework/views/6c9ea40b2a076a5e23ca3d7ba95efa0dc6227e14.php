<script src="<?php echo e(url('/app-assets/vendors/js/vendors.min.js')); ?>"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo e(url('/app-assets/vendors/js/charts/apexcharts.min.js')); ?>"></script>
<!-- END: Page Vendor JS-->
<script src="<?php echo e(url('/app-assets/vendors/js/extensions/dropzone.min.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js')); ?>"></script>
<!-- BEGIN: Theme JS-->
<script src="<?php echo e(url('/app-assets/js/core/app-menu.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/js/core/app.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/js/scripts/components.js')); ?>"></script>
<!-- END: Theme JS-->
<script src="<?php echo e(url('/app-assets/js/scripts/pages/app-chat.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/js/scripts/ui/data-list-view.js')); ?>"></script>
<script src="<?php echo e(url('/app-assets/js/scripts/datatables/datatable.js')); ?>"></script>
<!-- BEGIN: Page JS-->
<script src="<?php echo e(url('/app-assets/js/scripts/pages/dashboard-ecommerce.js')); ?>"></script>

<?php /**PATH E:\XAMPP\htdocs\seller-panel\resources\views/master/script.blade.php ENDPATH**/ ?>