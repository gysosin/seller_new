<!DOCTYPE html>
<html>
<head>
    <title>Laravel 7 Ajax Request example</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
</head>
<body>
  
    <div class="container">
        <h1>Laravel 7 Ajax Request example</h1>
  
         <form  method="post">
            <?php echo csrf_field(); ?>
           
      
            <?php 
            $email="rukhsar@whiteforce.com";
                ?>
         <input type="email" name="email" class="form-control" value="<?php echo e($email); ?>">
            <div class="form-group">
               
                <li  onclick="getPaging(this.id)"  id="<?php echo e($email); ?>">test </li>
                <button class="btn btn-success btn-submit">Submit</button> 
            </div>
  
        </form> 
      
    </div>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

    <input id="someInput" >
    <button class="btn btn-success .company-selector"  >clickme </button> 
  
</body>
<script>
    $('.company-selector ').click(function(e) {
     e.preventDefault();

     var companyId = $(this).data("someInput");
alert(companyId);

      $.ajax({
          headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          url: '/chat/' + companyId,
          dataType : 'json',
          type: 'POST',
          data: {},
          contentType: false,
          processData: false,
          success:function(response) {
               console.log(response);
          }
     });
  });
</script>
<script type="text/javascript">
   
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
   
     $(".btn-submit").click(function(e){ 
 
   
        e.preventDefault();
   
       
       // var email = $("input[name=email]").val();
   
        $.ajax({
           type:'POST',
           url:"<?php echo e(url('/chat')); ?>",
           data:{ email:email},
           success:function(data){
             // alert(data.success);
           }
           .fail(function(jqXHR, textStatus, errorThrown){
    if(jqXHR.status == 404) {

    }
        });
  
    });
});
</script>
   
</html><?php /**PATH C:\xampp\htdocs\AI-chatbot\resources\views/ajaxRequest.blade.php ENDPATH**/ ?>