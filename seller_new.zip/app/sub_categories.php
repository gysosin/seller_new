<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sub_categories extends Model
{
    //
}
