<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class purchases extends Model
{
    //
}
